# ================================================
# bot.py
# ================================================
import asyncio
import logging
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)
from telegram.constants import ParseMode
import database as db
import worker as wk
from config import BOT_TOKEN, ADMIN_ID, ADMIN_USERNAME

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

pending_requests: dict[int, dict] = {}
broadcast_state: dict[int, str]   = {}
withdraw_state: dict[int, dict]   = {}
app: Application = None
aiosqlite_lock = asyncio.Lock()


# ================================================
# YORDAMCHILAR
# ================================================

async def is_authorized(user_id: int) -> bool:
    if user_id == ADMIN_ID:
        return True
    return await db.is_whitelisted(user_id)


def get_number_keyboard(number: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("❌ Cancel",   callback_data=f"cancel:{number}"),
        InlineKeyboardButton("🧊 Freeze",   callback_data=f"freeze:{number}"),
        InlineKeyboardButton("📨 Get Code", callback_data=f"getcode:{number}"),
    ]])


def get_code_keyboard(number: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 Get code again", callback_data=f"getcode:{number}")],
        [InlineKeyboardButton("⭐ Check premium",  callback_data=f"checkpremium:{number}")],
        [InlineKeyboardButton("🧊 Freeze",          callback_data=f"freeze:{number}")],
        [InlineKeyboardButton("❌ Cancel",           callback_data=f"cancel:{number}")],
    ])


async def notify_admin(text: str):
    try:
        await app.bot.send_message(ADMIN_ID, text, parse_mode=ParseMode.HTML)
    except Exception:
        pass


# ================================================
# WORKER CALLBACKLARI
# ================================================

async def cb_number_received(worker_idx, number, bot_msg_id):
    pass


async def cb_limit_reached(worker_idx):
    logger.warning(f"Worker {worker_idx} limitga yetdi")
    for uid, info in list(pending_requests.items()):
        if info.get("worker_idx") == worker_idx:
            try:
                await app.bot.send_message(
                    uid,
                    "😔 Hozir bizda raqamlar mavjud emas.\n"
                    "Tez orada raqamlar bo'shagach sizga xabar beramiz! 🔔"
                )
            except Exception:
                pass
            pending_requests.pop(uid, None)


async def cb_disabled(worker_idx):
    await cb_limit_reached(worker_idx)


async def cb_code_result(worker_idx, number, code, password, last_get, has_error=False, raw_text=""):
    async with aiosqlite_lock:
        rec = await db.find_number_by_value_any_user(number)
    if not rec:
        return
    record_id, user_id, _, _, user_msg_id = rec

    if has_error:
        text = (
            f"❌ <b>Error: Login Code NotFound</b>\n\n"
            f"📞 <code>{number}</code>"
        )
        if last_get:
            text += f"\n🕐 Last GetCode: <code>{last_get}</code>"
    elif code:
        text = (
            f"📩 Code received:\n\n"
            f"📞 Number: <code>{number}</code>\n"
            f"🔐 Code: <code>{code}</code>\n"
            f"🔑 Pass: <code>{password}</code>"
        )
        if last_get:
            text += f"\n🕐 Last GetCode: <code>{last_get}</code>"
    else:
        text = (
            f"📞 Number: <code>{number}</code>\n\n"
            f"{raw_text}"
        )

    try:
        await app.bot.edit_message_text(
            chat_id=user_id,
            message_id=user_msg_id,
            text=text,
            parse_mode=ParseMode.HTML,
            reply_markup=get_code_keyboard(number)
        )
        await db.increment_stat(user_id, "total_codes")
    except Exception as ex:
        logger.error(f"cb_code_result: {ex}")


async def cb_premium_result(worker_idx, number, activated):
    if not number:
        return
    rec = await db.find_number_by_value_any_user(number)
    if not rec:
        return
    record_id, user_id, _, _, user_msg_id = rec
    if activated:
        await db.update_number_status(record_id, "premium")
        await db.increment_stat(user_id, "total_premium")
        try:
            await app.bot.edit_message_text(
                chat_id=user_id, message_id=user_msg_id,
                text=f"✅ <code>{number}</code> premium activated and counted.",
                parse_mode=ParseMode.HTML
            )
        except Exception as ex:
            logger.error(f"cb_premium_result: {ex}")
    else:
        try:
            await app.bot.edit_message_text(
                chat_id=user_id, message_id=user_msg_id,
                text=f"❌ <code>{number}</code> is not premium.",
                parse_mode=ParseMode.HTML,
                reply_markup=get_code_keyboard(number)
            )
        except Exception as ex:
            logger.error(f"cb_premium_result: {ex}")


async def cb_frozen_result(worker_idx, number):
    if not number:
        return
    rec = await db.find_number_by_value_any_user(number)
    if not rec:
        return
    record_id, user_id, _, _, user_msg_id = rec
    await db.update_number_status(record_id, "frozen")
    await db.increment_stat(user_id, "total_frozen")
    try:
        await app.bot.edit_message_text(
            chat_id=user_id, message_id=user_msg_id,
            text=f"🧊 <code>{number}</code> Number frozen successfully.",
            parse_mode=ParseMode.HTML
        )
    except Exception as ex:
        logger.error(f"cb_frozen_result: {ex}")


async def cb_cancelled_result(worker_idx, number):
    if not number:
        return
    rec = await db.find_number_by_value_any_user(number)
    if not rec:
        return
    record_id, user_id, _, _, user_msg_id = rec
    await db.update_number_status(record_id, "cancelled")
    await db.increment_stat(user_id, "total_cancelled")
    try:
        await app.bot.edit_message_text(
            chat_id=user_id, message_id=user_msg_id,
            text=f"❌ <code>{number}</code> Number cancelled and returned to free list.",
            parse_mode=ParseMode.HTML
        )
    except Exception as ex:
        logger.error(f"cb_cancelled_result: {ex}")


# ================================================
# BUYRUQLAR
# ================================================

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user    = update.effective_user
    user_id = user.id

    if await db.is_blocked(user_id):
        return

    authorized = await is_authorized(user_id)
    if not authorized:
        await update.message.reply_text(
            "🔒 Botdan foydalanish uchun admin bilan bog'laning:\n"
            f"{ADMIN_USERNAME}"
        )
        await notify_admin(
            f"🔔 Yangi /start:\n"
            f"👤 {user.full_name}\n🆔 {user_id}\n@{user.username or '—'}"
        )
        return

    if not await db.get_bot_enabled():
        await update.message.reply_text("🔴 Bot hozir o'chirilgan.")
        return

    await db.ensure_user(user_id, user.full_name, user.username or "")
    await update.message.reply_text(
        "👋 Xush kelibsiz!\n\nRaqam olish uchun /getNumber yozing.",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📊 My Stats", callback_data="mystats")],
            [InlineKeyboardButton("💸 Pul yechish", callback_data="withdraw")],
        ])
    )


async def cmd_get_number(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user    = update.effective_user
    user_id = user.id

    if await db.is_blocked(user_id):
        return
    if not await is_authorized(user_id):
        await update.message.reply_text(f"🔒 Ruxsat yo'q. Admin: {ADMIN_USERNAME}")
        return
    if not await db.get_bot_enabled():
        await update.message.reply_text("🔴 Bot hozir o'chirilgan.")
        return
    if wk.get_worker_count() == 0:
        await update.message.reply_text(
            "⚠️ Hech qanday akkount ulanmagan.\n"
            "Admin /admin → Akkountlar → ➕ Yangi orqali akkount ulishi kerak."
        )
        return

    await db.ensure_user(user_id, user.full_name, user.username or "")

    slot_limit = await db.get_slot_limit()
    active_cnt = await db.get_active_count(user_id)
    if active_cnt >= slot_limit:
        await update.message.reply_text(
            f"⚠️ Sizda {active_cnt} ta faol raqam bor (limit: {slot_limit}).\n"
            "Avval Cancel / Freeze / Check premium qiling."
        )
        return

    wait_msg = await update.message.reply_text("⏳ Raqam so'ralmoqda...")

    number, bot_msg_id = await _get_number_with_fallback()

    if number is None:
        await wait_msg.edit_text(
            "😔 Hozir bizda raqamlar mavjud emas.\n"
            "Tez orada raqamlar bo'shagach sizga xabar beramiz! 🔔"
        )
        return

    msg = await update.message.reply_text(
        f"📞 <b>Your number:</b>\n\n<code>{number}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_number_keyboard(number)
    )
    await wait_msg.delete()

    await db.add_active_number(user_id, number, 0, bot_msg_id, msg.message_id)
    await db.increment_stat(user_id, "total_numbers")


async def _get_number_with_fallback() -> tuple[str | None, int | None]:
    for idx in range(wk.get_worker_count()):
        await wk.send_to_target_bot(idx, "/getNumber")
        try:
            number, bot_msg_id = await asyncio.wait_for(
                wk.worker_get_number(idx), timeout=30
            )
        except asyncio.TimeoutError:
            number, bot_msg_id = None, None
        if number:
            return number, bot_msg_id
    return None, None


async def cmd_mystats(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if await db.is_blocked(user_id) or not await is_authorized(user_id):
        return
    await _send_stats(update.message, user_id)


async def _send_stats(msg_obj, user_id: int):
    s = await db.get_user_stats(user_id)
    if not s:
        text = "📊 Sizda hali statistika yo'q."
    else:
        text = (
            "📊 <b>Your Personal Stats:</b>\n\n"
            f"📞 My Numbers (Total): {s['total_numbers']}\n"
            f"❌ Canceled Numbers: {s['total_cancelled']}\n"
            f"🧊 Frozen Numbers: {s['total_frozen']}\n"
            f"📨 Codes received: {s['total_codes']}\n"
            f"⭐ Premium numbers: {s['total_premium']}"
        )
    await msg_obj.reply_text(text, parse_mode=ParseMode.HTML)


# ================================================
# INLINE BUTTONLAR
# ================================================

async def button_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query   = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    data    = query.data

    if await db.is_blocked(user_id):
        return

    if data == "withdraw":
        await _start_withdraw(query, user_id)
        return

    if data.startswith("admin_withdraw:"):
        if user_id != ADMIN_ID:
            return
        await _admin_withdraw_action(query, data)
        return

    if data == "mystats":
        s = await db.get_user_stats(user_id)
        if not s:
            text = "📊 Sizda hali statistika yo'q."
        else:
            text = (
                "📊 <b>Your Personal Stats:</b>\n\n"
                f"📞 My Numbers (Total): {s['total_numbers']}\n"
                f"❌ Canceled Numbers: {s['total_cancelled']}\n"
                f"🧊 Frozen Numbers: {s['total_frozen']}\n"
                f"📨 Codes received: {s['total_codes']}\n"
                f"⭐ Premium numbers: {s['total_premium']}"
            )
        await query.edit_message_text(text, parse_mode=ParseMode.HTML)
        return

    if data.startswith("admin:"):
        await _admin_button(query, data[6:], user_id)
        return

    # Akkount ulash tugmalari
    if data == "add_account":
        if user_id != ADMIN_ID:
            return
        text = await wk.begin_add_account(user_id)
        await query.edit_message_text(text, parse_mode=ParseMode.HTML)
        return

    if data.startswith("disconnect_acc:"):
        if user_id != ADMIN_ID:
            return
        sname = data.split(":", 1)[1]
        ok = await wk.disconnect_worker_by_session(sname)
        if ok:
            await query.edit_message_text(f"🔴 <b>{sname}</b> o'chirildi.", parse_mode=ParseMode.HTML)
        else:
            await query.edit_message_text(f"❌ {sname} topilmadi yoki allaqachon o'chiq.")
        return

    if data == "refresh_accounts":
        if user_id != ADMIN_ID:
            return
        await _show_accounts_panel(query)
        return

    # Raqam amallari
    parts  = data.split(":", 1)
    action = parts[0]
    number = parts[1] if len(parts) > 1 else ""

    if not number:
        await query.answer("❌ Raqam topilmadi.", show_alert=True)
        return

    rec = await db.find_number_record(user_id, number)
    if not rec:
        await query.answer("❌ Bu raqam topilmadi yoki qayta ishlangan.", show_alert=True)
        return

    record_id, acc_idx, bot_msg_id, user_msg_id, status = rec

    if action == "cancel":
        ok = await wk.worker_click_button(acc_idx, number, "cancel")
        if ok:
            await query.edit_message_text(
                f"❌ <code>{number}</code> Number cancelled and returned to free list.",
                parse_mode=ParseMode.HTML
            )
            await db.update_number_status(record_id, "cancelled")
            await db.increment_stat(user_id, "total_cancelled")
        else:
            await query.answer("❌ Cancel qilib bo'lmadi.", show_alert=True)

    elif action == "freeze":
        ok = await wk.worker_click_button(acc_idx, number, "freeze")
        if ok:
            await query.edit_message_text(
                f"🧊 <code>{number}</code> Number frozen successfully.",
                parse_mode=ParseMode.HTML
            )
            await db.update_number_status(record_id, "frozen")
            await db.increment_stat(user_id, "total_frozen")
        else:
            await query.answer("❌ Freeze qilib bo'lmadi.", show_alert=True)

    elif action == "getcode":
        ok = await wk.worker_click_button(acc_idx, number, "get code")
        if ok:
            try:
                await app.bot.edit_message_text(
                    chat_id=query.from_user.id,
                    message_id=query.message.message_id,
                    text=f"📞 <b>Raqam:</b> <code>{number}</code>\n\n⏳ Kod so'ralmoqda...",
                    parse_mode=ParseMode.HTML
                )
                await db.update_user_msg_id(record_id, query.message.message_id)
            except Exception:
                pass
        else:
            await query.answer("❌ Kod so'rab bo'lmadi.", show_alert=True)

    elif action == "checkpremium":
        ok = await wk.worker_click_button(acc_idx, number, "check premium")
        if not ok:
            await query.answer("❌ Check premium qilib bo'lmadi.", show_alert=True)


# ================================================
# ADMIN PANEL
# ================================================

async def cmd_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    await _send_admin_panel(update.message)


async def _send_admin_panel(msg_obj):
    bot_enabled   = await db.get_bot_enabled()
    slot_limit    = await db.get_slot_limit()
    wl_count      = len(await db.get_whitelist())
    worker_count  = wk.get_worker_count()
    all_s         = await db.get_all_stats()
    total_premium = sum(r[5] for r in all_s) if all_s else 0

    status_text = "🟢 Yoniq" if bot_enabled else "🔴 O'chiq"
    toggle_text = "🔴 O'chirish" if bot_enabled else "🟢 Yoqish"

    text = (
        f"🛠 <b>Admin Panel</b>\n\n"
        f"Status: {status_text}\n"
        f"🔗 Ulangan workerlar: <b>{worker_count}</b> ta\n"
        f"👥 Whitelist: {wl_count} kishi\n"
        f"⭐ Jami premium: {total_premium}\n"
        f"🔢 Slot limit: {slot_limit} ta"
    )
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(toggle_text,        callback_data="admin:toggle_bot")],
        [
            InlineKeyboardButton("👥 Whitelist",  callback_data="admin:whitelist"),
            InlineKeyboardButton("🚫 Blocklist",  callback_data="admin:blocklist"),
        ],
        [
            InlineKeyboardButton("📊 Statistika", callback_data="admin:allstats"),
            InlineKeyboardButton("♻️ Resetall",   callback_data="admin:resetall"),
        ],
        [InlineKeyboardButton("📢 Broadcast",     callback_data="admin:broadcast")],
        [InlineKeyboardButton("⚙️ Slot limit",    callback_data="admin:slotlimit")],
        [InlineKeyboardButton("🔗 Akkountlar",    callback_data="admin:accounts")],
    ])
    await msg_obj.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=keyboard)


async def _admin_button(query, action: str, user_id: int):
    if user_id != ADMIN_ID:
        return

    if action == "toggle_bot":
        enabled = await db.get_bot_enabled()
        await db.set_setting("bot_enabled", "0" if enabled else "1")
        state = "🟢 Yoqildi" if not enabled else "🔴 O'chirildi"
        await query.edit_message_text(f"Bot holati: {state}")

    elif action == "whitelist":
        wl = await db.get_whitelist()
        if not wl:
            text = "👥 Whitelist bo'sh."
        else:
            lines = ["👥 <b>Whitelist:</b>\n"]
            for uid, name, uname in wl:
                u = f"@{uname}" if uname else ""
                lines.append(f"• {name} {u} (<code>{uid}</code>)")
            text = "\n".join(lines)
        await query.edit_message_text(text, parse_mode=ParseMode.HTML)

    elif action == "blocklist":
        bl = await db.get_blocked_list()
        if not bl:
            text = "🚫 Bloklangan yo'q."
        else:
            lines = ["🚫 <b>Bloklangan:</b>\n"]
            for uid, name in bl:
                lines.append(f"• {name} (<code>{uid}</code>)")
            text = "\n".join(lines)
        await query.edit_message_text(text, parse_mode=ParseMode.HTML)

    elif action == "allstats":
        rows = await db.get_all_stats()
        if not rows:
            text = "📊 Statistika yo'q."
        else:
            lines = ["📊 <b>Umumiy statistika:</b>\n"]
            for r in rows:
                uid, name, uname, tn, tc, tp, tf, tca = r
                lines.append(f"👤 {name}: 📞{tn} 📨{tc} ⭐{tp} 🧊{tf} ❌{tca}")
            text = "\n".join(lines)
        await query.edit_message_text(text, parse_mode=ParseMode.HTML)

    elif action == "resetall":
        await db.reset_all_stats()
        await query.edit_message_text("♻️ Barcha statistikalar 0 ga tushirildi.")

    elif action == "broadcast":
        broadcast_state[ADMIN_ID] = "waiting_message"
        await query.edit_message_text(
            "📢 Broadcast xabarini yuboring:\n(Matn, rasm, video, ovoz)"
        )

    elif action == "slotlimit":
        current = await db.get_slot_limit()
        broadcast_state[ADMIN_ID] = "waiting_slotlimit"
        await query.edit_message_text(
            f"⚙️ Hozirgi slot limit: <b>{current}</b>\n\nYangi limitni kiriting (1-50):",
            parse_mode=ParseMode.HTML
        )

    elif action == "accounts":
        await _show_accounts_panel(query)


async def _show_accounts_panel(query):
    """Akkountlar paneli"""
    statuses = await wk.get_account_statuses()
    worker_count = wk.get_worker_count()

    lines = [f"🔗 <b>Akkountlar</b> ({worker_count} ta aktiv)\n"]
    buttons = []

    if statuses:
        for s in statuses:
            icon = "🟢" if s["connected"] else "🔴"
            lines.append(f"{icon} <b>{s['session']}</b>: {s['phone']}")
            if s["connected"]:
                buttons.append([InlineKeyboardButton(
                    f"🔌 {s['session']} o'chirish",
                    callback_data=f"disconnect_acc:{s['session']}"
                )])
    else:
        lines.append("Hali hech qanday akkount ulanmagan.")

    buttons.append([InlineKeyboardButton("➕ Yangi akkount ulash", callback_data="add_account")])
    buttons.append([InlineKeyboardButton("🔄 Yangilash", callback_data="refresh_accounts")])

    await query.edit_message_text(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(buttons)
    )


# ================================================
# ADMIN BUYRUQLARI
# ================================================

async def cmd_allow(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not ctx.args:
        await update.message.reply_text("Ishlatish: /allow <user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Noto'g'ri ID.")
        return
    try:
        chat  = await app.bot.get_chat(target_id)
        name  = chat.full_name or str(target_id)
        uname = chat.username or ""
    except Exception:
        name, uname = str(target_id), ""

    ok = await db.add_to_whitelist(target_id, name, uname)
    if ok:
        await update.message.reply_text(
            f"✅ {name} (<code>{target_id}</code>) ruxsat berildi.",
            parse_mode=ParseMode.HTML
        )
        try:
            await app.bot.send_message(target_id, "✅ Ruxsat berildi! /start bosing.")
        except Exception:
            pass
    else:
        await update.message.reply_text("⚠️ Allaqachon qo'shilgan.")


async def cmd_block(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not ctx.args:
        await update.message.reply_text("Ishlatish: /block <user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Noto'g'ri ID.")
        return
    if target_id == ADMIN_ID:
        await update.message.reply_text("❌ O'zingizni bloklashingiz mumkin emas.")
        return
    try:
        chat = await app.bot.get_chat(target_id)
        name = chat.full_name or str(target_id)
    except Exception:
        name = str(target_id)
    await db.block_user(target_id, name)
    await db.remove_from_whitelist(target_id)
    await update.message.reply_text(
        f"🚫 {name} (<code>{target_id}</code>) bloklandi.",
        parse_mode=ParseMode.HTML
    )


async def cmd_unblock(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not ctx.args:
        await update.message.reply_text("Ishlatish: /unblock <user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Noto'g'ri ID.")
        return
    ok = await db.unblock_user(target_id)
    msg = f"✅ <code>{target_id}</code> blokdan chiqarildi." if ok else "⚠️ Bloklangan emas."
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML)


async def cmd_resetuser(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    if not ctx.args:
        await update.message.reply_text("Ishlatish: /resetuser <user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Noto'g'ri ID.")
        return
    await db.reset_user_stats(target_id)
    await update.message.reply_text(
        f"♻️ <code>{target_id}</code> statistikasi nollandi.",
        parse_mode=ParseMode.HTML
    )


async def cmd_boton(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    await db.set_setting("bot_enabled", "1")
    await update.message.reply_text("🟢 Bot yoqildi.")


async def cmd_botoff(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    await db.set_setting("bot_enabled", "0")
    await update.message.reply_text("🔴 Bot o'chirildi.")


async def cmd_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        return
    if wk.is_in_login_flow(user_id):
        await wk.cancel_login_flow(user_id)
        await update.message.reply_text("❌ Akkount ulash bekor qilindi.")
    else:
        await update.message.reply_text("Hozir aktiv jarayon yo'q.")


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if await db.is_blocked(user_id):
        return
    if user_id == ADMIN_ID:
        text = (
            "📖 <b>Admin buyruqlari:</b>\n\n"
            "/admin — panel\n"
            "/allow &lt;id&gt; — ruxsat berish\n"
            "/block &lt;id&gt; — bloklash\n"
            "/unblock &lt;id&gt; — blokdan chiqarish\n"
            "/resetuser &lt;id&gt; — statistikani nollash\n"
            "/boton — botni yoqish\n"
            "/botoff — botni o'chirish\n"
            "/cancel — akkount ulashni bekor qilish\n\n"
            "📖 <b>Foydalanuvchi buyruqlari:</b>\n\n"
            "/getNumber — raqam olish\n"
            "/mystats — statistika"
        )
    else:
        text = (
            "📖 <b>Buyruqlar:</b>\n\n"
            "/getNumber — raqam olish\n"
            "/mystats — statistikam\n"
            "/help — yordam"
        )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


# ================================================
# XABARLAR (broadcast + login flow)
# ================================================

async def handle_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text    = update.message.text or ""

    # Admin login jarayoni
    if user_id == ADMIN_ID and wk.is_in_login_flow(user_id):
        if text.startswith("/"):
            return
        response, done = await wk.process_login_input(user_id, text)
        await update.message.reply_text(response, parse_mode=ParseMode.HTML)
        return

    # Withdraw jarayoni (har qanday foydalanuvchi)
    if user_id in withdraw_state:
        if text.startswith("/"):
            withdraw_state.pop(user_id, None)
            return
        await _process_withdraw_input(update, user_id, text)
        return

    # Admin broadcast / slotlimit
    if user_id == ADMIN_ID and user_id in broadcast_state:
        state = broadcast_state.pop(user_id)

        if state == "waiting_slotlimit":
            try:
                val = int(text.strip())
                if 1 <= val <= 50:
                    await db.set_setting("slot_limit", str(val))
                    await update.message.reply_text(f"✅ Slot limit {val} ga o'rnatildi.")
                else:
                    await update.message.reply_text("❌ 1 dan 50 gacha son kiriting.")
            except ValueError:
                await update.message.reply_text("❌ Raqam kiriting.")
            return

        if state == "waiting_message":
            await _do_broadcast(update, ctx)
            return


async def _start_withdraw(query, user_id: int):
    """Pul yechish jarayonini boshlaydi"""
    s = await db.get_user_stats(user_id)
    premium = s["total_premium"] if s else 0
    if premium == 0:
        await query.answer("❌ Sizda premium yo'q!", show_alert=True)
        return
    withdraw_state[user_id] = {"step": "amount"}
    await query.edit_message_text(
        f"💸 <b>Pul yechish</b>\n\n"
        f"⭐ Sizda: <b>{premium} ta premium</b>\n\n"
        "Nechta premium uchun pul yechmoqchisiz?\n"
        "Raqam kiriting:",
        parse_mode="HTML"
    )


async def _process_withdraw_input(update, user_id: int, text: str):
    """Withdraw jarayonidagi har bir qadamni qayta ishlaydi"""
    sess = withdraw_state.get(user_id, {})
    step = sess.get("step")

    if step == "amount":
        try:
            amount = int(text.strip())
            if amount <= 0:
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ To'g'ri raqam kiriting:")
            return
        s = await db.get_user_stats(user_id)
        premium = s["total_premium"] if s else 0
        if amount > premium:
            await update.message.reply_text(
                f"❌ Yetarli premium yo'q!\nSizda: <b>{premium} ta</b>",
                parse_mode="HTML"
            )
            return
        sess["amount"] = amount
        sess["step"] = "card"
        await update.message.reply_text(
            f"💳 <b>{amount} ta premium</b> uchun pul yechish\n\n"
            "Karta raqamingizni kiriting:\n"
            "(16 raqam, masalan: <code>9860123456789012</code>)",
            parse_mode="HTML"
        )

    elif step == "card":
        card = text.strip().replace(" ", "")
        if not card.isdigit() or len(card) < 13 or len(card) > 19:
            await update.message.reply_text("❌ Noto'g'ri karta raqam. Qaytadan kiriting:")
            return
        sess["card"] = card
        sess["step"] = "bank"
        await update.message.reply_text(
            "🏦 Bank nomini kiriting:\n"
            "(masalan: <code>Aloqa Bank</code>, <code>Kapitalbank</code>, <code>Uzcard</code>)",
            parse_mode="HTML"
        )

    elif step == "bank":
        bank = text.strip()
        if len(bank) < 2:
            await update.message.reply_text("❌ Bank nomini to'g'ri kiriting:")
            return
        sess["bank"] = bank
        withdraw_state.pop(user_id, None)

        user = update.effective_user
        amount = sess["amount"]
        card = sess["card"]

        # DB ga saqlash
        withdraw_id = await db.create_withdrawal(
            user_id, user.full_name, user.username or "",
            amount, card, bank
        )

        # Foydalanuvchiga tasdiqlash
        await update.message.reply_text(
            f"✅ <b>So'rovingiz yuborildi!</b>\n\n"
            f"⭐ Miqdor: <b>{amount} ta premium</b>\n"
            f"💳 Karta: <code>{card}</code>\n"
            f"🏦 Bank: {bank}\n\n"
            "Admin tasdiqlashini kuting.",
            parse_mode="HTML"
        )

        # Adminga xabar
        uname = f"@{user.username}" if user.username else str(user_id)
        await notify_admin(
            f"💸 <b>Yangi pul yechish so'rovi!</b>\n\n"
            f"👤 {user.full_name} ({uname})\n"
            f"🆔 <code>{user_id}</code>\n"
            f"⭐ Miqdor: <b>{amount} ta premium</b>\n"
            f"💳 Karta: <code>{card}</code>\n"
            f"🏦 Bank: {bank}\n"
            f"🔢 So'rov #{withdraw_id}",
        )
        await app.bot.send_message(
            ADMIN_ID,
            f"Tasdiqlash uchun quyidagi tugmani bosing:",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ Tasdiqlash", callback_data=f"admin_withdraw:approve:{withdraw_id}"),
                InlineKeyboardButton("❌ Rad etish",  callback_data=f"admin_withdraw:reject:{withdraw_id}"),
            ]])
        )


async def _admin_withdraw_action(query, data: str):
    """Admin withdraw ni tasdiqlash yoki rad etishi"""
    parts = data.split(":")
    action = parts[1]
    withdraw_id = int(parts[2])

    row = await db.get_withdrawal(withdraw_id)
    if not row:
        await query.edit_message_text("❌ So'rov topilmadi.")
        return

    wid, user_id, full_name, username, amount, card, bank, status = row

    if status != "pending":
        await query.edit_message_text(f"⚠️ Bu so'rov allaqachon: <b>{status}</b>", parse_mode="HTML")
        return

    uname = f"@{username}" if username else str(user_id)

    if action == "approve":
        ok = await db.deduct_premium(user_id, amount)
        if not ok:
            await query.edit_message_text(
                f"❌ {full_name} da yetarli premium yo'q! So'rov bekor qilindi."
            )
            await db.update_withdrawal_status(withdraw_id, "rejected")
            try:
                await app.bot.send_message(user_id,
                    "❌ Pul yechish so'rovingiz rad etildi: yetarli premium yo'q.")
            except Exception:
                pass
            return

        await db.update_withdrawal_status(withdraw_id, "approved")
        await query.edit_message_text(
            f"✅ <b>Tasdiqlandi!</b>\n\n"
            f"👤 {full_name} ({uname})\n"
            f"⭐ {amount} ta premium ayirildi\n"
            f"💳 Karta: <code>{card}</code>\n"
            f"🏦 Bank: {bank}",
            parse_mode="HTML"
        )
        try:
            await app.bot.send_message(user_id,
                f"✅ <b>Pul yechish tasdiqlandi!</b>\n\n"
                f"⭐ {amount} ta premium hisobingizdan ayirildi.\n"
                f"💳 {card} ({bank}) kartangizga pul o'tkaziladi.",
                parse_mode="HTML"
            )
        except Exception:
            pass

    elif action == "reject":
        await db.update_withdrawal_status(withdraw_id, "rejected")
        await query.edit_message_text(
            f"❌ <b>Rad etildi</b>\n\n"
            f"👤 {full_name} ({uname})\n"
            f"⭐ {amount} ta premium\n"
            f"💳 {card} | {bank}",
            parse_mode="HTML"
        )
        try:
            await app.bot.send_message(user_id,
                "❌ Afsuski, pul yechish so'rovingiz rad etildi.\n"
                "Batafsil ma'lumot uchun admin bilan bog'laning.",
                parse_mode="HTML"
            )
        except Exception:
            pass



async def _do_broadcast(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    wl     = await db.get_whitelist()
    sent   = 0
    failed = 0
    msg    = update.message
    for uid, name, _ in wl:
        try:
            await ctx.bot.copy_message(
                chat_id=uid,
                from_chat_id=msg.chat_id,
                message_id=msg.message_id
            )
            sent += 1
            await asyncio.sleep(0.3)
        except Exception as ex:
            logger.error(f"Broadcast {uid}: {ex}")
            failed += 1
    await update.message.reply_text(f"📤 Yuborildi: {sent}\n❌ Xato: {failed}")


# ================================================
# ISHGA TUSHIRISH
# ================================================

async def post_init(application: Application):
    global app
    app = application

    await db.init_db()
    await db.init_withdraw_table()

    wk.set_callbacks(
        on_number=cb_number_received,
        on_limit=cb_limit_reached,
        on_disabled=cb_disabled,
        on_code=cb_code_result,
        on_premium=cb_premium_result,
        on_frozen=cb_frozen_result,
        on_cancelled=cb_cancelled_result,
    )

    await wk.start_workers()

    await application.bot.set_my_commands([
        BotCommand("start",     "Botni ishga tushirish"),
        BotCommand("getnumber", "Raqam olish"),
        BotCommand("mystats",   "Mening statistikam"),
        BotCommand("help",      "Yordam"),
    ])

    logger.info("✅ Bot tayyor!")


async def post_shutdown(application: Application):
    await wk.stop_workers()


def main():
    application = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    application.add_handler(CommandHandler("start",      cmd_start))
    application.add_handler(CommandHandler("getNumber",  cmd_get_number))
    application.add_handler(CommandHandler("getnumber",  cmd_get_number))
    application.add_handler(CommandHandler("mystats",    cmd_mystats))
    application.add_handler(CommandHandler("help",       cmd_help))
    application.add_handler(CommandHandler("admin",      cmd_admin))
    application.add_handler(CommandHandler("allow",      cmd_allow))
    application.add_handler(CommandHandler("block",      cmd_block))
    application.add_handler(CommandHandler("unblock",    cmd_unblock))
    application.add_handler(CommandHandler("resetuser",  cmd_resetuser))
    application.add_handler(CommandHandler("boton",      cmd_boton))
    application.add_handler(CommandHandler("botoff",     cmd_botoff))
    application.add_handler(CommandHandler("cancel",     cmd_cancel))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(
        filters.ALL & ~filters.COMMAND,
        handle_message
    ))

    logger.info("🚀 Bot ishga tushmoqda...")
    application.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
