#!/bin/bash
# Bot ishga tushirish skripti (Linux server uchun)
cd "$(dirname "$0")"
pip install -r requirements.txt -q
python bot.py
