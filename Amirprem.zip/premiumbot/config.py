# config.py
BOT_TOKEN = "8958224581:AAG84OwZ3HuJ8RtJg_GEVNhjvab6XRUbJpI"
ADMIN_ID  = 6760971351
ADMIN_USERNAME = "@OLD_XAVEN"
TARGET_BOT = "@Pre_Plus_bot"
DEFAULT_SLOT_LIMIT = 5
DB_FILE = "bot_database2.db"

ACCOUNTS = [
    {
        "session": "session2_1",
        "api_id":   23651528,
        "api_hash": "ca42cf77a78ee409550aac24e179c87e",
    },
    {
        "session": "session2_2",
        "api_id":   23651528,
        "api_hash": "ca42cf77a78ee409550aac24e179c87e",
    },
]
