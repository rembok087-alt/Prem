# ================================================
# database.py
# ================================================
import aiosqlite
import asyncio
from config import DB_FILE, DEFAULT_SLOT_LIMIT

_lock = asyncio.Lock()

async def init_db():
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS whitelist (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT,
                username TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS blocked (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS stats (
                user_id INTEGER PRIMARY KEY,
                full_name TEXT,
                username TEXT,
                total_numbers INTEGER DEFAULT 0,
                total_codes INTEGER DEFAULT 0,
                total_premium INTEGER DEFAULT 0,
                total_frozen INTEGER DEFAULT 0,
                total_cancelled INTEGER DEFAULT 0
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS active_numbers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                number TEXT,
                account_index INTEGER,
                bot_msg_id INTEGER,
                user_msg_id INTEGER,
                status TEXT DEFAULT 'active'
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        # Sessiyalar jadvali — bot ichidan qo'shiladi
        await db.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_name TEXT UNIQUE,
                phone TEXT,
                api_id INTEGER,
                api_hash TEXT,
                active INTEGER DEFAULT 1
            )
        """)
        # Default sozlamalar
        await db.execute("""
            INSERT OR IGNORE INTO settings (key, value) VALUES ('bot_enabled', '1')
        """)
        await db.execute(f"""
            INSERT OR IGNORE INTO settings (key, value) VALUES ('slot_limit', '{DEFAULT_SLOT_LIMIT}')
        """)
        await db.commit()


async def get_setting(key: str) -> str | None:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
        return row[0] if row else None


async def set_setting(key: str, value: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))
        await db.commit()


async def get_bot_enabled() -> bool:
    val = await get_setting("bot_enabled")
    return val == "1"


async def get_slot_limit() -> int:
    val = await get_setting("slot_limit")
    try:
        return int(val)
    except Exception:
        return DEFAULT_SLOT_LIMIT


async def is_whitelisted(user_id: int) -> bool:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT 1 FROM whitelist WHERE user_id=?", (user_id,))
        return await cur.fetchone() is not None


async def is_blocked(user_id: int) -> bool:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT 1 FROM blocked WHERE user_id=?", (user_id,))
        return await cur.fetchone() is not None


async def add_to_whitelist(user_id: int, full_name: str, username: str) -> bool:
    async with aiosqlite.connect(DB_FILE) as db:
        try:
            await db.execute(
                "INSERT OR IGNORE INTO whitelist (user_id, full_name, username) VALUES (?,?,?)",
                (user_id, full_name, username)
            )
            await db.commit()
            cur = await db.execute("SELECT changes()")
            row = await cur.fetchone()
            return row[0] > 0
        except Exception:
            return False


async def remove_from_whitelist(user_id: int):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM whitelist WHERE user_id=?", (user_id,))
        await db.commit()


async def block_user(user_id: int, full_name: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "INSERT OR REPLACE INTO blocked (user_id, full_name) VALUES (?,?)",
            (user_id, full_name)
        )
        await db.commit()


async def unblock_user(user_id: int) -> bool:
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM blocked WHERE user_id=?", (user_id,))
        await db.commit()
        cur = await db.execute("SELECT changes()")
        row = await cur.fetchone()
        return row[0] > 0


async def get_whitelist() -> list:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT user_id, full_name, username FROM whitelist")
        return await cur.fetchall()


async def get_blocked_list() -> list:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT user_id, full_name FROM blocked")
        return await cur.fetchall()


async def ensure_user(user_id: int, full_name: str, username: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "INSERT OR IGNORE INTO stats (user_id, full_name, username) VALUES (?,?,?)",
            (user_id, full_name, username)
        )
        await db.commit()


async def increment_stat(user_id: int, field: str):
    allowed = {"total_numbers", "total_codes", "total_premium", "total_frozen", "total_cancelled"}
    if field not in allowed:
        return
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(f"UPDATE stats SET {field}={field}+1 WHERE user_id=?", (user_id,))
        await db.commit()


async def get_user_stats(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT total_numbers, total_codes, total_premium, total_frozen, total_cancelled FROM stats WHERE user_id=?",
            (user_id,)
        )
        row = await cur.fetchone()
        if not row:
            return None
        return {
            "total_numbers":   row[0],
            "total_codes":     row[1],
            "total_premium":   row[2],
            "total_frozen":    row[3],
            "total_cancelled": row[4],
        }


async def get_all_stats() -> list:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT user_id, full_name, username, total_numbers, total_codes, total_premium, total_frozen, total_cancelled FROM stats"
        )
        return await cur.fetchall()


async def reset_all_stats():
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE stats SET total_numbers=0, total_codes=0, total_premium=0, total_frozen=0, total_cancelled=0"
        )
        await db.commit()


async def reset_user_stats(user_id: int):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE stats SET total_numbers=0, total_codes=0, total_premium=0, total_frozen=0, total_cancelled=0 WHERE user_id=?",
            (user_id,)
        )
        await db.commit()


async def add_active_number(user_id: int, number: str, account_index: int,
                             bot_msg_id: int | None, user_msg_id: int):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "INSERT INTO active_numbers (user_id, number, account_index, bot_msg_id, user_msg_id, status) VALUES (?,?,?,?,?,'active')",
            (user_id, number, account_index, bot_msg_id, user_msg_id)
        )
        await db.commit()


async def get_active_count(user_id: int) -> int:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT COUNT(*) FROM active_numbers WHERE user_id=? AND status='active'",
            (user_id,)
        )
        row = await cur.fetchone()
        return row[0] if row else 0


async def find_number_record(user_id: int, number: str):
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT id, account_index, bot_msg_id, user_msg_id, status FROM active_numbers WHERE user_id=? AND number=? AND status='active' ORDER BY id DESC LIMIT 1",
            (user_id, number)
        )
        return await cur.fetchone()


async def find_number_by_value_any_user(number: str):
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT id, user_id, account_index, bot_msg_id, user_msg_id FROM active_numbers WHERE number=? AND status='active' ORDER BY id DESC LIMIT 1",
            (number,)
        )
        row = await cur.fetchone()
        if row:
            return row
        cur = await db.execute(
            "SELECT id, user_id, account_index, bot_msg_id, user_msg_id FROM active_numbers WHERE number=? ORDER BY id DESC LIMIT 1",
            (number,)
        )
        return await cur.fetchone()


async def update_number_status(record_id: int, status: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE active_numbers SET status=? WHERE id=?",
            (status, record_id)
        )
        await db.commit()


# ================================================
# SESSIYALAR (bot ichidan boshqarish)
# ================================================

async def get_all_sessions() -> list:
    """Barcha saqlangan sessiyalar"""
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT id, session_name, phone, api_id, api_hash, active FROM sessions ORDER BY id"
        )
        return await cur.fetchall()


async def save_session(session_name: str, phone: str, api_id: int, api_hash: str) -> int:
    """Yangi sessiyani saqlaydi yoki yangilaydi. id qaytaradi."""
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            """INSERT INTO sessions (session_name, phone, api_id, api_hash, active)
               VALUES (?,?,?,?,1)
               ON CONFLICT(session_name) DO UPDATE SET
               phone=excluded.phone, active=1""",
            (session_name, phone, api_id, api_hash)
        )
        await db.commit()
        cur = await db.execute("SELECT id FROM sessions WHERE session_name=?", (session_name,))
        row = await cur.fetchone()
        return row[0] if row else 0


async def deactivate_session(session_name: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("UPDATE sessions SET active=0 WHERE session_name=?", (session_name,))
        await db.commit()


async def delete_session(session_name: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("DELETE FROM sessions WHERE session_name=?", (session_name,))
        await db.commit()


async def get_active_sessions() -> list:
    """Faqat active=1 bo'lgan sessiyalar"""
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT id, session_name, phone, api_id, api_hash FROM sessions WHERE active=1 ORDER BY id"
        )
        return await cur.fetchall()


# ================================================
# WITHDRAW (Pul yechish) funksiyalari
# ================================================

async def init_withdraw_table():
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                full_name TEXT,
                username TEXT,
                amount INTEGER,
                card_number TEXT,
                bank_name TEXT,
                status TEXT DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()


async def create_withdrawal(user_id: int, full_name: str, username: str,
                             amount: int, card_number: str, bank_name: str) -> int:
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            """INSERT INTO withdrawals (user_id, full_name, username, amount, card_number, bank_name)
               VALUES (?,?,?,?,?,?)""",
            (user_id, full_name, username, amount, card_number, bank_name)
        )
        await db.commit()
        return cur.lastrowid


async def get_withdrawal(withdraw_id: int):
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute(
            "SELECT id, user_id, full_name, username, amount, card_number, bank_name, status FROM withdrawals WHERE id=?",
            (withdraw_id,)
        )
        return await cur.fetchone()


async def update_withdrawal_status(withdraw_id: int, status: str):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("UPDATE withdrawals SET status=? WHERE id=?", (status, withdraw_id))
        await db.commit()


async def deduct_premium(user_id: int, amount: int) -> bool:
    """Foydalanuvchidan premium ayiradi. Yetarli bo'lmasa False qaytaradi."""
    async with aiosqlite.connect(DB_FILE) as db:
        cur = await db.execute("SELECT total_premium FROM stats WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        if not row or row[0] < amount:
            return False
        await db.execute(
            "UPDATE stats SET total_premium=total_premium-? WHERE user_id=?",
            (amount, user_id)
        )
        await db.commit()
        return True


async def update_user_msg_id(record_id: int, new_msg_id: int):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            "UPDATE active_numbers SET user_msg_id=? WHERE id=?",
            (new_msg_id, record_id)
        )
        await db.commit()
