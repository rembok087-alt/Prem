# worker.py
import asyncio
import re
import logging
from telethon import TelegramClient, events
from telethon.errors import FloodWaitError, SessionPasswordNeededError
from config import ACCOUNTS, TARGET_BOT
import database as db

logger = logging.getLogger(__name__)

workers: list[TelegramClient] = []
_queues: list[asyncio.Queue] = []

_on_number_received  = None
_on_limit_reached    = None
_on_disabled         = None
_on_code_result      = None
_on_premium_result   = None
_on_frozen_result    = None
_on_cancelled_result = None

login_sessions: dict[int, dict] = {}


def set_callbacks(on_number=None, on_limit=None, on_disabled=None,
                  on_code=None, on_premium=None, on_frozen=None, on_cancelled=None):
    global _on_number_received, _on_limit_reached, _on_disabled
    global _on_code_result, _on_premium_result, _on_frozen_result, _on_cancelled_result
    _on_number_received  = on_number
    _on_limit_reached    = on_limit
    _on_disabled         = on_disabled
    _on_code_result      = on_code
    _on_premium_result   = on_premium
    _on_frozen_result    = on_frozen
    _on_cancelled_result = on_cancelled


def extract_number(text: str) -> str | None:
    nums = re.findall(r'\d{6,}', text or "")
    return max(nums, key=len) if nums else None


def clean(text: str) -> str:
    """Backtick va ortiqcha belgilarni tozalaydi"""
    return text.replace('`', '').strip()


def parse_code_message(text: str) -> dict:
    result = {"number": "", "code": "", "password": "", "last_get": "", "has_error": False}
    tl = text.lower()
    if "login code notfound" in tl or ("error" in tl and "number:" in tl):
        result["has_error"] = True
    for line in text.split('\n'):
        line = line.strip()
        ll = line.lower()
        if 'number:' in ll:
            m = re.search(r'number[:\s`]*(\d+)', line, re.IGNORECASE)
            if m: result["number"] = m.group(1)
        elif 'code:' in ll and 'last' not in ll and 'getcode' not in ll:
            m = re.search(r'code[:\s`]*(\d+)', line, re.IGNORECASE)
            if m: result["code"] = m.group(1)
        elif 'pass:' in ll:
            m = re.search(r'pass[:\s`]*(\d+)', line, re.IGNORECASE)
            if m: result["password"] = m.group(1)
        elif 'last getcode' in ll:
            m = re.search(r'last getcode[:\s]+(.+)', line, re.IGNORECASE)
            if m: result["last_get"] = clean(m.group(1))
    if not result["number"]:
        result["number"] = extract_number(text) or ""
    return result


async def safe_send(client: TelegramClient, target, text):
    for _ in range(5):
        try:
            return await client.send_message(target, text)
        except FloodWaitError as e:
            await asyncio.sleep(e.seconds + 2)
        except Exception as ex:
            logger.error(f"safe_send xato: {ex}")
            return None
    return None


async def safe_click(msg, keyword: str) -> bool:
    try:
        if not msg.buttons:
            return False
        for row in msg.buttons:
            for btn in row:
                if keyword.lower() in btn.text.lower():
                    await msg.click(text=btn.text)
                    return True
        return False
    except Exception as ex:
        logger.error(f"safe_click xato ({keyword}): {ex}")
        return False


async def find_msg_by_last4(client: TelegramClient, last4: str, limit=200):
    async for msg in client.iter_messages(TARGET_BOT, limit=limit):
        if msg.text and last4 in msg.text and msg.buttons:
            return msg
    return None


def _clear_queue(idx: int):
    if idx >= len(_queues):
        return
    while not _queues[idx].empty():
        try:
            fut = _queues[idx].get_nowait()
            if not fut.done():
                fut.set_result((None, None))
        except asyncio.QueueEmpty:
            break


def _setup_worker_handlers(client: TelegramClient, idx: int):

    @client.on(events.NewMessage(chats=TARGET_BOT))
    async def on_new(event):
        text = event.text or ""
        tl = text.lower()

        if "disabled by admin" in tl or "currently disabled" in tl:
            if _on_disabled:
                asyncio.create_task(_on_disabled(idx))
            _clear_queue(idx)
            return

        if "limit reached" in tl:
            if _on_limit_reached:
                asyncio.create_task(_on_limit_reached(idx))
            _clear_queue(idx)
            return

        if "your number" in tl:
            number = extract_number(text)
            if number and idx < len(_queues) and not _queues[idx].empty():
                try:
                    fut = _queues[idx].get_nowait()
                    if not fut.done():
                        fut.set_result((number, event.id))
                except asyncio.QueueEmpty:
                    pass
            return

        # Yangi xabar sifatida kod kelsa
        is_code_msg = (
            "code received" in tl or
            "new code" in tl or
            "login code notfound" in tl or
            ("code:" in tl and "number:" in tl)
        )
        if is_code_msg:
            parsed = parse_code_message(text)
            number = parsed["number"]
            if number and _on_code_result:
                asyncio.create_task(_on_code_result(
                    idx, number, parsed["code"], parsed["password"],
                    parsed["last_get"], parsed["has_error"], text,
                ))
            return

        if "frozen successfully" in tl:
            number = extract_number(text)
            if number and _on_frozen_result:
                asyncio.create_task(_on_frozen_result(idx, number))
            return

        if "cancelled and returned" in tl or "number cancelled" in tl:
            number = extract_number(text)
            if number and _on_cancelled_result:
                asyncio.create_task(_on_cancelled_result(idx, number))
            return

        if "premium activated" in tl or "not premium" in tl:
            number = extract_number(text)
            activated = "premium activated" in tl
            if _on_premium_result:
                asyncio.create_task(_on_premium_result(idx, number, activated))
            return

    @client.on(events.MessageEdited(chats=TARGET_BOT))
    async def on_edited(event):
        text = event.text or ""
        tl = text.lower()

        is_code_msg = (
            "code received" in tl or
            "new code" in tl or
            "login code notfound" in tl or
            ("error" in tl and "number:" in tl) or
            ("code:" in tl and "number:" in tl)
        )
        if is_code_msg:
            parsed = parse_code_message(text)
            number = parsed["number"]
            if number and _on_code_result:
                asyncio.create_task(_on_code_result(
                    idx, number, parsed["code"], parsed["password"],
                    parsed["last_get"], parsed["has_error"], text,
                ))
            return

        if "premium activated" in tl or "not premium" in tl:
            number = extract_number(text)
            activated = "premium activated" in tl
            if _on_premium_result:
                asyncio.create_task(_on_premium_result(idx, number, activated))
            return

        if "frozen successfully" in tl:
            number = extract_number(text)
            if number and _on_frozen_result:
                asyncio.create_task(_on_frozen_result(idx, number))
            return

        if "cancelled and returned" in tl or "number cancelled" in tl:
            number = extract_number(text)
            if number and _on_cancelled_result:
                asyncio.create_task(_on_cancelled_result(idx, number))
            return


async def start_workers():
    global workers, _queues
    workers = []
    _queues = []
    sessions = await db.get_active_sessions()
    if not sessions:
        # config.py dagi ACCOUNTS dan yuklaymiz
        for i, acc in enumerate(ACCOUNTS):
            session_name = acc.get("session", f"session{i+1}")
            try:
                c = TelegramClient(session_name, acc["api_id"], acc["api_hash"])
                await c.connect()
                if await c.is_user_authorized():
                    _setup_worker_handlers(c, len(workers))
                    workers.append(c)
                    _queues.append(asyncio.Queue())
                    logger.info(f"Worker {i} ishga tushdi: {session_name}")
                else:
                    logger.warning(f"Worker {i} avtorizatsiya qilinmagan: {session_name}")
                    await c.disconnect()
            except Exception as ex:
                logger.error(f"Worker {i} xato: {ex}")
    else:
        for i, (sid, session_name, phone, api_id, api_hash) in enumerate(sessions):
            try:
                c = TelegramClient(session_name, api_id, api_hash)
                await c.connect()
                if await c.is_user_authorized():
                    _setup_worker_handlers(c, len(workers))
                    workers.append(c)
                    _queues.append(asyncio.Queue())
                    logger.info(f"Worker {i} ishga tushdi: {session_name} ({phone})")
                else:
                    logger.warning(f"Worker {i} avtorizatsiya qilinmagan: {session_name}")
                    await c.disconnect()
            except Exception as ex:
                logger.error(f"Worker {i} xato: {ex}")

    logger.info(f"Ishga tushgan workerlar: {len(workers)} ta")


async def stop_workers():
    for c in workers:
        try:
            await c.disconnect()
        except Exception:
            pass


def get_worker_count() -> int:
    return len(workers)


async def send_to_target_bot(worker_idx: int, text: str):
    if worker_idx >= len(workers):
        return None
    return await safe_send(workers[worker_idx], TARGET_BOT, text)


async def worker_get_number(worker_idx: int) -> tuple:
    if worker_idx >= len(_queues):
        return None, None
    future = asyncio.get_event_loop().create_future()
    await _queues[worker_idx].put(future)
    return await future


async def worker_click_button(worker_idx: int, number: str, keyword: str) -> bool:
    if worker_idx >= len(workers):
        return False
    client = workers[worker_idx]
    last4 = number[-4:]
    msg = await find_msg_by_last4(client, last4)
    if msg:
        return await safe_click(msg, keyword)
    return False


# ================================================
# DINAMIK AKKOUNT ULASH
# ================================================

async def get_account_statuses() -> list[dict]:
    sessions = await db.get_active_sessions()
    statuses = []
    for i, (sid, session_name, phone, api_id, api_hash) in enumerate(sessions):
        connected = False
        for w in workers:
            try:
                if w.session.filename and session_name in w.session.filename:
                    if await w.is_user_authorized():
                        connected = True
                        break
            except Exception:
                pass
        statuses.append({
            "idx": i,
            "session": session_name,
            "phone": phone,
            "connected": connected,
        })
    return statuses


async def begin_add_account(admin_id: int) -> str:
    from config import ACCOUNTS
    # Keyingi bo'sh session nomini topamiz
    existing = await db.get_active_sessions()
    acc_idx = len(existing)
    if acc_idx >= len(ACCOUNTS):
        return (
            f"❌ config.py da faqat {len(ACCOUNTS)} ta akkount uchun api_id/api_hash bor.\n"
            "Yangi akkount qo'shish uchun config.py ga yangi element qo'shing."
        )
    acc = ACCOUNTS[acc_idx]
    session_name = acc.get("session", f"session{acc_idx+1}")

    if admin_id in login_sessions:
        try:
            await login_sessions[admin_id]["client"].disconnect()
        except Exception:
            pass

    client = TelegramClient(session_name, acc["api_id"], acc["api_hash"])
    await client.connect()

    if await client.is_user_authorized():
        me = await client.get_me()
        await client.disconnect()
        return f"✅ Bu sessiya allaqachon ulangan: +{me.phone}"

    login_sessions[admin_id] = {
        "step": "phone",
        "client": client,
        "acc_idx": acc_idx,
        "session": session_name,
        "api_id": acc["api_id"],
        "api_hash": acc["api_hash"],
        "phone": "",
    }
    return (
        f"📱 <b>Yangi akkount ulash</b> ({session_name})\n\n"
        "Telefon raqamni kiriting:\n"
        "(masalan: <code>+998901234567</code>)\n\n"
        "/cancel — bekor qilish"
    )


async def process_login_input(admin_id: int, text: str) -> tuple[str, bool]:
    if admin_id not in login_sessions:
        return "❌ Login jarayoni topilmadi.", True

    sess = login_sessions[admin_id]
    client: TelegramClient = sess["client"]
    step = sess["step"]

    try:
        if step == "phone":
            phone = text.strip()
            sess["phone"] = phone
            await client.send_code_request(phone)
            sess["step"] = "code"
            return (
                f"📨 <code>{phone}</code> ga SMS kod yuborildi.\n\nKodni kiriting:",
                False
            )
        elif step == "code":
            code = text.strip()
            try:
                await client.sign_in(sess["phone"], code)
            except SessionPasswordNeededError:
                sess["step"] = "password"
                return "🔒 2FA parol kerak. Parolni kiriting:", False
            return await _finish_login(admin_id, client)

        elif step == "password":
            await client.sign_in(password=text.strip())
            return await _finish_login(admin_id, client)

    except Exception as ex:
        login_sessions.pop(admin_id, None)
        try:
            await client.disconnect()
        except Exception:
            pass
        return f"❌ Xato: {ex}\n\nQaytadan /admin → Akkountlar", True

    return "❌ Noma'lum holat.", True


async def _finish_login(admin_id: int, client: TelegramClient) -> tuple[str, bool]:
    sess = login_sessions.pop(admin_id)
    me = await client.get_me()
    phone = f"+{me.phone}"

    await db.save_session(sess["session"], phone, sess["api_id"], sess["api_hash"])

    idx = len(workers)
    workers.append(client)
    _queues.append(asyncio.Queue())
    _setup_worker_handlers(client, idx)

    logger.info(f"Worker {idx} dinamik ulandi: {phone}")
    return (
        f"✅ Muvaffaqiyatli ulandi!\n\n"
        f"📱 Telefon: <code>{phone}</code>\n"
        f"👤 Ism: {me.first_name}\n"
        f"🔗 Session: {sess['session']}",
        True
    )


def is_in_login_flow(admin_id: int) -> bool:
    return admin_id in login_sessions


async def cancel_login_flow(admin_id: int):
    if admin_id in login_sessions:
        try:
            await login_sessions[admin_id]["client"].disconnect()
        except Exception:
            pass
        login_sessions.pop(admin_id, None)
